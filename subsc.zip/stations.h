void buildGraph();
bool bfs(int start, int end, int parent[]);
void calc_kit_kat_index();
string findShortestPath(int start, int end);
int find_st_num(string start);
int not_fixed(int station_num);
string getCurrentDate();
float calculated_fare(int zone);
