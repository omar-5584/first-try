#include "structures.h"

RideInfo rides[MAX_rides];
st_of_users arr_users[usersnum];
plan arr_subscription[20];
st_of_users newacc;
Station allStations[MAX_STATIONS_PER_LINE][NUM_LINES];
