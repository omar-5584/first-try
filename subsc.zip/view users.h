#include "global.h"
#include "dependence.h"
#include "data.h"

void view_users_toAdmin();
