#pragma once
#include<iostream>
#include <cstdlib>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <string>
#include <fstream>
#include <chrono>
#include <ctime>
#include <conio.h>
#include <utility>
#include <sstream>
#include<QString>
#include<QMessageBox>
#include<QDebug>
#include <QDate>
using namespace std;